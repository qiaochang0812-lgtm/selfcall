# NovaCustomerDialer（Nova 客户拨号助手）

面向 Android / 华为 nova 10 的客户回访队列原型。Kotlin + Jetpack Compose。

## 当前功能
- 从文件选择器导入 CSV / XLSX（无需通讯录权限）；CSV 自动识别 UTF-8 / GBK 编码，支持引号内的逗号和换行；XLSX 读取全部工作表
- 识别姓名、手机号、备注列（建议列顺序：姓名,手机号,备注）
- 按客户队列查看进度、点选切换客户
- “清晰高效”工作台：优先展示下一位客户、到期回访和稍后回访
- 首页及拨号名单支持一键直拨，连续拨号页固定显示当前线路和大号拨号按钮
- 系统默认、SIM1、SIM2 三种固定卡拨号方式；点击“一键拨打当前客户”直接发起通话
- 按拨号轮换模式：可为每张 SIM 设置连续拨出 1、2、3、5 或 10 次后自动换卡
- 轮换在通话界面真正接管前台后才计数；权限不足、系统拦截或 SIM 账户异常不会消耗轮换次数。换卡按实际检测到的可用卡槽顺序循环
- 设置页提供 SIM/Telecom 账户状态、权限说明、授权和系统设置入口
- 手动记录已接通、未接听、稍后回访、拒绝
- 不申请网络、通讯录、短信或定位权限

## Android 权限
- `CALL_PHONE`：用户点击拨号按钮后直接拨出电话，指定 SIM 时必需。
- `READ_PHONE_STATE`：读取活动 SIM 和通话账户，用于把 SIM1/SIM2 映射到 Android Telecom 账户，指定 SIM 或轮换时必需。
- `READ_CALL_LOG`：可选；用于匹配客户最近通话并生成拨出次数、接通次数和时长统计。

## 导入格式
```csv
姓名,手机号,备注
张三,13800138000,续约回访
李四,+8613900000000,新客户
```
- CSV 可为 UTF-8（含 BOM）或 GBK；Excel 另存的 CSV 可直接导入。
- 号码保留开头的 `+`；同一号码带或不带 86 前缀视为重复。
- 回访日期列支持 `2026/11/2`、`2026年11月2日` 和 Excel 日期序列号，统一转换为 `yyyy-MM-dd`。
- 单次最多读取 200000 行。

## GitHub Actions 编译
每次推送到 `main`/`master`，或手动运行 Actions 中的 **Build Android APK**：
- 已配置签名密钥（Secrets：`KEYSTORE_BASE64`、`KEYSTORE_PASSWORD`、`KEY_ALIAS`、`KEY_PASSWORD`）：构建签名 release 包，产物 `NovaCustomerDialer-release`（`app-release.apk`）。release 开启了 R8 压缩混淆。
- 未配置密钥：自动回退为 debug 包，产物 `NovaCustomerDialer-debug`。
- 同时运行单元测试（`testDebugUnitTest`），测试失败只提示、不阻断出包。

下载方式：GitHub 仓库 → Actions → 选择成功的工作流运行 → Artifacts。

## 本机编译
需要 JDK 17、Android SDK（API 35）和 Gradle 8.9：
```bash
gradle -PstandaloneDebug=true assembleDebug
```
输出路径：`app/build/outputs/apk/debug/app-debug.apk`。`standaloneDebug` 会沿用正式 applicationId，便于在本机直接替换测试；不传该参数时调试包使用 `.debug` 后缀，可与现有版本共存。

## 说明
- 当前是可编译原型，不是已验证可在所有 EMUI/HarmonyOS/各品牌系统运行的正式产品。纯血鸿蒙（HarmonyOS NEXT）不能安装 APK。
- 双卡映射依次尝试：账户 ID 等于订阅 ID、ID 等于 ICCID（Android 8/9）、ID 中包含订阅 ID、系统返回顺序。仅靠“系统返回顺序”推测的映射不一定可靠，界面会标注“顺序推测”。**换到新机型后，请先用指定 SIM 拨打自己的号码，确认实际走的是哪张卡。**
- 部分系统（小米/OPPO/vivo 等）可能对第三方应用直拨电话弹出确认或将权限默认设为“询问”，需在系统权限管理中改为允许，否则连续拨号会被打断。
- 客户数据保存在应用私有目录的 `customers.json`（后台原子写入），首次启动会自动从旧版 SharedPreferences 迁移，旧数据不会被删除；标签和设置仍在 SharedPreferences。卸载应用或清除应用数据后数据会丢失，请定期使用“导出”备份。下一阶段建议迁移到 Room。
- 应用已启用边到边显示（targetSdk 35 在 Android 15 上强制），顶栏会避开状态栏。
- 本项目仅在用户主动点击拨号按钮后发起通话。请仅联系有合理联系依据、允许联系的客户，控制联系频率，并遵守当地电话营销和隐私法规。

## 更新记录
- 0.10.0：修复选卡兜底可能静默拨错卡（新增 ICCID 匹配与“顺序推测”提示）；轮换计数与结果弹窗改为通话界面接管前台后才触发；号码保留 `+`；去重统一处理 86 前缀；通话记录查询与客户数据写入移出主线程，客户列表筛选加缓存；适配 Android 15 边到边；导入支持 GBK、多行引号、全部工作表、科学计数法和日期序列号；轮换支持两张以上的卡；release 启用 R8；CI 无密钥时回退 debug 构建并增加单元测试。
